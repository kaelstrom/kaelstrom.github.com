Kyle Johnsen
kaelstrom@gmail.com
203-648-8586

Portfolio updated winter 2010-2011

A lot of what you see here originated in game jams, 
	club run events where a group of teams gets a topic and has 
	8 hours to try and make a game within those constraints.
	I use gamemaker for these competitions, because what it does
	really well is development speed.

Veneficus is my first game jam entry, made by Brett Kaplan and me.  
	Our topic for the 8 hour competition was hunter and prey.
	It's a fast paced competitive multiplayer action game.
	Controls- P1:WASD + V P2:Arrows + enter
	Collect mana to shoot homing magic attacks at the other wizard!
	The more mana you have, the stronger your attack will be.  
	The less mana you have, the faster you are.
	With no mana, you can outrun all attacks but can't fight back.
	Shooting uses up your mana in one go.
	Power ups float by on the screen, they boost your next shot.
	A powered up shot can one-hit kill the enemy.
	Your health is you maximum mana.
	I did design, art, sound, and minimal coding.
	There were originally only 2 maps and some movement bugs that got ironed out after the competition.
	It won Most Entertaining and Best Overall.
	
Glorious Cave Raid is another game jam entry by Brett and me.
	The 8 hour competition topic was exploration.
	It's a wall avoidance type of game where you try to glide down a crevasse without hitting any obstacles.
	There are 3 sections to get through, each progressively harder.
	Left and right control direction.  
	The glider movement was a lot of fun to design.  Wish we had done a wider map to really make the most of it.
	All the obstacles you see are procedurally generated as squares on a grid,
	and then each square is given a sprite matching how many collisions it has, and the sprite is rotated to look smooth.
	I did design, art, movement code, and sprite choosing code.
	We won Technical Excellence.
	
HueShift was a game made back in freshman year before these other projects.
	It was for a presentation in Game Mechanics.
	I went into the project not knowing python, and used it as a crash course to learn the language.
	I ended up very happy with how easy pygame was to work with.
	"Click the center box to start the game.
	Click or hold the mouse to place pieces.
	Each piece puts influence on the tile it's on, and each 3 pieces increases the range.
	Each piece's influence adds about 20% control per turn.
	Once you control 40% of a tile, it will give you a new piece each turn.
	The top center bar shows whose turn it is.
	The bars to the top left and right show a player's surge.  
	Once it fills, they will get a temporary influence on all tiles.
	Press m to launch a missile. Missiles cost 3 and destroy 6 pieces from both players at a tile.
	Press b to launch a bomb.  Bombs cost 6 and destroy 2 pieces from both players at each tile in a 3 by 3 grid.
	Get 75% control to win!"
	I picked mechanics trying to force choices between spreading out thin or clustering up, and gave
	the opponent ways to punish the other player for favoring a strategy too exclusively.
	The surge is negative feedback to give the losing player a leg up.
	
Fungsurrection is my latest game jam entry, made by Brett Kaplan, Oliver Daniels, and me.
	The 8 hour competition topic was invasion.
	You play as a demonic fungus sprouting in a national forest preserve.
	You need to infect trees to power yourself, but pesky park rangers are coming in and cleansing the infection!
	Controls: Click to launch a spore that infects trees, 
		right click to launch a pre-infected tree, 
		middle mouse click to launch a massive boulder.
	If a ranger gets surrounded by infected trees, they will solidify.
	Infect trees for energy, your abilities aren't free. Your energy is the bottom right bar.
	You win by infecting 75% of the forest.  You lose by getting touched by a ranger.
	Make walls of infected trees around you to slow down incoming threats.  
	A boulder costs half a full energy bar, have fun with it!
	The more forest you infect, the more people sign up to be park rangers.
	Since the competition, a lot of bugs have been ironed out.
	I did design, art, and sound.
	We won Most Entertaining and Best Overall
	
Potential Field Demo is a WIP for an RTS Screensaver I'm currently working on.
	It shows off a bit of the AI stuff that's fun to visualize.
	Inspired by http://aigamedev.com/open/tutorials/potential-fields/

Fiducia is a visual novel made for an interactive narrative course by Sylvia Forrest, Brett Kaplan, and me.
	It has modular scenes that appear based on user actions and multiple endings.
	I did the majority of coding.  It's written in renpy, a python based engine.
	None of us were authors, so writing quality leaves something to be desired.