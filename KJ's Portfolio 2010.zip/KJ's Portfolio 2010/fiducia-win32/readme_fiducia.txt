Sylvia Forrest- art, writing
Brett Kaplan- writing, coding
Kyle Johnsen- coding, writing

Fiducia- Visual Novel- Ren'Py

Fiducia is a game centered around overcoming personal barriers to gain trust and help others. The player is not so much a character in the game, as a catalyst for change in the other characters.

Like most visual novels, there are several endings, but there is only one truly "good end" among various "bad ends". Replay is encouraged to see all the endings, and to see all the dialogue choices (not all of which affect outcome-- there is some variation in there just to keep things interesting).

To run the game, extract the zip and run fiducia.exe.
The full script can be found in game/script.rpy