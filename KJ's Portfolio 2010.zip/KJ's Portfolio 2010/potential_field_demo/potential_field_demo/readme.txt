Potential Field Demo
Kyle Johnsen

Here's a snapshot of the RTS screensaver I've been working on.  This app demos the potential field based movement system.
There are 2 potential fields, one for each team.  Tanks add to the potential field, creating the brightest points at the maximum
shooting range.  The tanks then look at the field and move towards the brightest areas.  I've heard this called the raindrop
technique, making units move to max range but not cluster all the way in.  Still needs tweaking.

It alternates displaying one field and then the other, and the cursor displays field level at that spot.

inspired by http://aigamedev.com/open/tutorials/potential-fields/